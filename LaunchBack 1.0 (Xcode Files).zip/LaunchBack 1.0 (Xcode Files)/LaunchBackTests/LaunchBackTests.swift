//
//  LaunchBackTests.swift
//  LaunchBackTests
//
//  Created by Thomas Aldridge II on 6/22/25.
//

import Testing
@testable import LaunchBack

struct LaunchBackTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
